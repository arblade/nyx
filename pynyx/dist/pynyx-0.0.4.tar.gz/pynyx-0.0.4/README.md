# PyNyx

A python tool to convert nyx format into suricata and snort.